Copy Falcon 9 into the VAB and the Barge into the SPH folder.

You can use these crafts in your videos but don't forget to credit me ;P